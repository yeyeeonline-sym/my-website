# 生命之轮评估工具

一个帮助你评估生活各方面平衡状况的交互式工具，通过可视化图表和个性化分析，助你实现更平衡、更有意义的生活。

## 功能特点

- 多维度生活评估：身体健康、情绪健康、心智成长等8个核心维度
- 个性化雷达图和饼图可视化展示
- 详细的生活平衡分析报告
- 基于评估结果的个性化行动计划建议
- 生命长度可视化和倒计时功能

## 本地开发

### 环境要求

- Node.js 16.x 或更高版本
- pnpm 包管理器

### 安装与运行

1. 克隆项目到本地
```bash
git clone <项目仓库地址>
cd life-wheel-assessment
```

2. 安装依赖
```bash
pnpm install
```

3. 启动开发服务器
```bash
pnpm dev
```

4. 在浏览器中访问 `http://localhost:3000`

## 非同一网络访问方案

### 方案一：使用 ngrok 临时访问（适合测试）

ngrok 可以将你的本地服务器临时暴露到公网，实现不同网络环境下的访问：

1. 安装 ngrok（如果尚未安装）
```bash
# 对于 macOS
brew install ngrok

# 对于 Windows
choco install ngrok

# 其他系统可从官网下载：https://ngrok.com/download
```

2. 启动本地开发服务器
```bash
pnpm dev
```

3. 在新的终端窗口中，运行 ngrok 暴露本地端口
```bash
ngrok http 3000
```

4. ngrok 会生成一个公网 URL（如：https://xxxx-xx-xx-xx-xx.ngrok.io），复制此 URL 即可在任何网络环境下访问

> **注意**：免费版 ngrok 生成的 URL 会在 8 小时后过期，且每次启动 ngrok 都会生成新的 URL，适合临时测试使用。

### 方案二：部署到第三方平台（适合长期使用）

#### Netlify 部署

1. 将项目代码推送到 GitHub 仓库

2. 访问 [Netlify](https://www.netlify.com/) 并使用 GitHub 账号登录

3. 点击 "New site from Git"，选择你的项目仓库

4. 在构建设置中：
   - 构建命令：`pnpm build`
   - 发布目录：`dist/static`

5. 点击 "Deploy site"，等待部署完成

6. 部署成功后，Netlify 会提供一个随机 URL（如：https://xxxx-xxxx.netlify.app），你可以通过此 URL 在任何网络访问

#### Vercel 部署

1. 将项目代码推送到 GitHub 仓库

2. 访问 [Vercel](https://vercel.com/) 并使用 GitHub 账号登录

3. 点击 "New Project"，导入你的项目仓库

4. 在项目设置中：
   - 构建命令：`pnpm build`
   - 输出目录：`dist/static`

5. 点击 "Deploy"，等待部署完成

6. 部署成功后，Vercel 会提供一个 URL（如：https://xxxx.vercel.app），你可以通过此 URL 在任何网络访问

## 常见问题

### Q: 部署后页面显示空白怎么办？
A: 检查构建命令和发布目录是否正确设置，确保构建过程没有错误。可以在部署平台的构建日志中查看详细错误信息。

### Q: ngrok 生成的 URL 无法访问怎么办？
A: 确保本地开发服务器正在运行，且 ngrok 命令中的端口号与开发服务器端口一致（默认 3000）。

### Q: 如何自定义域名？
A: Netlify 和 Vercel 都支持自定义域名，在项目设置的域名部分可以添加和配置你的自定义域名，需要在域名提供商处进行相应的 DNS 设置。

## 技术栈

- React 18
- TypeScript
- Tailwind CSS
- Recharts 数据可视化
- Vite 构建工具